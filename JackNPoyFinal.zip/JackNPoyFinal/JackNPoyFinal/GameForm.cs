﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace JackNPoyFinal
{
    public partial class GameForm : Form
    {



        public string YW = "YouWin";
        public string YL = "YouLose!";
        public string playername;
        
        public GameForm()
        {
            InitializeComponent();
            
            
        }

        

        private void GameForm_Load(object sender, EventArgs e)
        {
            LblScissor.Hide();
            LblPaper.Hide();
            LblRock.Hide();
            LblUserCard.Hide();
            label1.Text = playername;
            PnlUserCard.BackgroundImage = Properties.Resources.BackCard;
            PnlComputerCard.BackgroundImage = Properties.Resources.BackCard;

        }
        private void BtnScissor_Click(object sender, EventArgs e)
        {
            LblScissor.Show();
            LblPaper.Hide();
            LblRock.Hide();  
            LblUserCard.Text = "Scissor";
            PnlUserCard.BackgroundImage = Properties.Resources.BackCard;
            PnlComputerCard.BackgroundImage = Properties.Resources.BackCard;
            PNLoutcome.Hide();

        }
        private void BtnPaper_Click(object sender, EventArgs e)
        {
            LblPaper.Show();
            LblScissor.Hide();
            LblRock.Hide();
            LblUserCard.Text = "Paper";
            PnlUserCard.BackgroundImage = Properties.Resources.BackCard;
            PnlComputerCard.BackgroundImage = Properties.Resources.BackCard;
            PNLoutcome.Hide();
        }
        private void BtnRock_Click(object sender, EventArgs e)
        {
            LblRock.Show();
            LblPaper.Hide();
            LblScissor.Hide();
            LblUserCard.Text = "Rock";
            PnlUserCard.BackgroundImage = Properties.Resources.BackCard;
            PnlComputerCard.BackgroundImage = Properties.Resources.BackCard;
            PNLoutcome.Hide();
           

        }
        private void button4_Click(object sender, EventArgs e)
        {
            Random ComputerCardNum = new Random();
            int CCN = ComputerCardNum.Next(1, 4);

            int US = Convert.ToInt32(UserScore.Text);
            int CS = Convert.ToInt32(ComputerScore.Text);

            RestartForm Rform = new RestartForm();

            PNLoutcome.Show();

            if (LblUserCard.Text == "Scissor")
            {
                PnlUserCard.BackgroundImage = Properties.Resources.Scissor;

                if (CCN == 1)
                {
                    PnlComputerCard.BackgroundImage = Properties.Resources.Scissor;
                    PNLoutcome.BackgroundImage = Properties.Resources.draw;
                   
                }
                else if (CCN == 2)
                {
                    US++;
                    String updateUS = Convert.ToString(US);
                    UserScore.Text = updateUS;
                    PnlComputerCard.BackgroundImage = Properties.Resources.Papers;
                    PNLoutcome.BackgroundImage = Properties.Resources.PWins;


                }
                else if (CCN == 3)
                {
                    CS++;
                    String updateCS = Convert.ToString(CS);
                    ComputerScore.Text = updateCS;
                    PnlComputerCard.BackgroundImage = Properties.Resources.Rock;
                    PNLoutcome.BackgroundImage = Properties.Resources.AIWins;
                }
            }
            else if (LblUserCard.Text == "Paper")
            {
                PnlUserCard.BackgroundImage = Properties.Resources.Papers;
                if (CCN == 2)
                {
                    PnlComputerCard.BackgroundImage = Properties.Resources.Papers;
                    PNLoutcome.BackgroundImage = Properties.Resources.draw;

                }
                else if (CCN == 3)
                {
                    // User win
                    US++;
                    String updateUS = Convert.ToString(US);
                    UserScore.Text = updateUS;
                    PnlComputerCard.BackgroundImage = Properties.Resources.Rock;
                    PNLoutcome.BackgroundImage = Properties.Resources.PWins;

                }
                else if (CCN == 1)
                {
                    //Computer win
                    CS++;
                    String updateCS = Convert.ToString(CS);
                    ComputerScore.Text = updateCS;
                    PnlComputerCard.BackgroundImage = Properties.Resources.Scissor;
                    PNLoutcome.BackgroundImage = Properties.Resources.AIWins;
                }
            }
            else if (LblUserCard.Text == "Rock")
            {
                PnlUserCard.BackgroundImage = Properties.Resources.Rock;
                if (CCN == 3)
                {
                    PnlComputerCard.BackgroundImage = Properties.Resources.Rock;
                    PNLoutcome.BackgroundImage = Properties.Resources.draw;

                }
                else if (CCN == 1)
                {
                    //User win
                    US++;
                    String updateUS = Convert.ToString(US);
                    UserScore.Text = updateUS;
                    PnlComputerCard.BackgroundImage = Properties.Resources.Scissor;
                    PNLoutcome.BackgroundImage = Properties.Resources.PWins;
                }
                else if (CCN == 2)
                {
                    //Computer win
                    CS++;
                    String updateCS = Convert.ToString(CS);
                    ComputerScore.Text = updateCS;
                    PnlComputerCard.BackgroundImage = Properties.Resources.Papers;
                    PNLoutcome.BackgroundImage = Properties.Resources.AIWins;
                }

            }

            

            if (US == 3)
            {
                
                LblPaper.Hide();
                LblScissor.Hide();
                LblRock.Hide();
                PNLoutcome.Hide();

                Rform.Status = YW;
                Rform.Show();
                this.Enabled = false;
                
                
            }
            else if (CS == 3)
            {
                
                LblPaper.Hide();
                LblScissor.Hide();
                LblRock.Hide();
                PNLoutcome.Hide();

                Rform.Status = YL;
                Rform.Show();
                this.Enabled = false;
            }

            

        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void UserScore_Click(object sender, EventArgs e)
        {
            
        }
        
       
    }
}
