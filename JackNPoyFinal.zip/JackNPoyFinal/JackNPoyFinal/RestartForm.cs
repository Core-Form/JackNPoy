﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace JackNPoyFinal
{
    public partial class RestartForm : Form
    {

        public string Status;
        public RestartForm()
        {
            InitializeComponent();
        }

       
        private void RestartForm_Load(object sender, EventArgs e)
        {
            LblResult.Text = Status;
           

        }

        private void BtnRestart_Click(object sender, EventArgs e)
        {
            this.Hide();
            GameForm Gform = new GameForm();
            Gform.Show();
            Gform.Enabled = true;
        }

        private void BtnQuit_Click(object sender, EventArgs e)
        {

            GameForm Gform = new GameForm();
            Gform.Close();
            this.Close();
            
        }

       

        private void LblResult_Click(object sender, EventArgs e)
        {


        }

        private void LblResult_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
