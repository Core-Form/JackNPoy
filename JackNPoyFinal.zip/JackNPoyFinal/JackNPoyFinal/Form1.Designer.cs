﻿namespace JackNPoyFinal
{
    partial class StartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StartForm));
            this.BtnUnmute = new System.Windows.Forms.Button();
            this.BtnMute = new System.Windows.Forms.Button();
            this.LblStart = new System.Windows.Forms.Label();
            this.TMBlinker = new System.Windows.Forms.Timer(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BtnUnmute
            // 
            this.BtnUnmute.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.BtnUnmute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnUnmute.BackgroundImage")));
            this.BtnUnmute.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnUnmute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnUnmute.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.BtnUnmute.Location = new System.Drawing.Point(476, 12);
            this.BtnUnmute.Name = "BtnUnmute";
            this.BtnUnmute.Size = new System.Drawing.Size(47, 47);
            this.BtnUnmute.TabIndex = 1;
            this.BtnUnmute.UseVisualStyleBackColor = false;
            this.BtnUnmute.Visible = false;
            this.BtnUnmute.Click += new System.EventHandler(this.BtnUnmute_Click_1);
            // 
            // BtnMute
            // 
            this.BtnMute.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.BtnMute.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnMute.BackgroundImage")));
            this.BtnMute.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnMute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMute.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.BtnMute.Location = new System.Drawing.Point(476, 12);
            this.BtnMute.Name = "BtnMute";
            this.BtnMute.Size = new System.Drawing.Size(47, 47);
            this.BtnMute.TabIndex = 2;
            this.BtnMute.UseVisualStyleBackColor = false;
            this.BtnMute.Click += new System.EventHandler(this.BtnMute_Click);
            // 
            // LblStart
            // 
            this.LblStart.AutoSize = true;
            this.LblStart.BackColor = System.Drawing.Color.Transparent;
            this.LblStart.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblStart.ForeColor = System.Drawing.Color.White;
            this.LblStart.Location = new System.Drawing.Point(148, 537);
            this.LblStart.Name = "LblStart";
            this.LblStart.Size = new System.Drawing.Size(222, 22);
            this.LblStart.TabIndex = 3;
            this.LblStart.Text = "Click anywhere to start";
            // 
            // TMBlinker
            // 
            this.TMBlinker.Tick += new System.EventHandler(this.TMBlinker_Tick);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(161, 459);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 27);
            this.textBox1.TabIndex = 4;
            // 
            // StartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(544, 712);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.LblStart);
            this.Controls.Add(this.BtnMute);
            this.Controls.Add(this.BtnUnmute);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Location = new System.Drawing.Point(100, 100);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(550, 750);
            this.Name = "StartForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "JackNPoy v1.2";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnUnmute;
        private System.Windows.Forms.Button BtnMute;
        private System.Windows.Forms.Label LblStart;
        private System.Windows.Forms.Timer TMBlinker;
        private System.Windows.Forms.TextBox textBox1;









    }
}

