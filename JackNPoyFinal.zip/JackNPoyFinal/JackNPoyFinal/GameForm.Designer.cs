﻿namespace JackNPoyFinal
{
    partial class GameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameForm));
            this.BtnScissor = new System.Windows.Forms.Button();
            this.BtnPaper = new System.Windows.Forms.Button();
            this.BtnRock = new System.Windows.Forms.Button();
            this.LblScissor = new System.Windows.Forms.Label();
            this.LblPaper = new System.Windows.Forms.Label();
            this.LblRock = new System.Windows.Forms.Label();
            this.PnlUserCard = new System.Windows.Forms.Panel();
            this.LblUserCard = new System.Windows.Forms.Label();
            this.PnlComputerCard = new System.Windows.Forms.Panel();
            this.BtnLockIn = new System.Windows.Forms.Button();
            this.PNLoutcome = new System.Windows.Forms.Panel();
            this.UserScore = new System.Windows.Forms.TextBox();
            this.ComputerScore = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PnlUserCard.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnScissor
            // 
            this.BtnScissor.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnScissor.BackgroundImage")));
            this.BtnScissor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnScissor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnScissor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnScissor.Location = new System.Drawing.Point(32, 458);
            this.BtnScissor.Name = "BtnScissor";
            this.BtnScissor.Size = new System.Drawing.Size(120, 230);
            this.BtnScissor.TabIndex = 0;
            this.BtnScissor.UseVisualStyleBackColor = true;
            this.BtnScissor.Click += new System.EventHandler(this.BtnScissor_Click);
            // 
            // BtnPaper
            // 
            this.BtnPaper.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnPaper.BackgroundImage")));
            this.BtnPaper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnPaper.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPaper.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnPaper.Location = new System.Drawing.Point(236, 458);
            this.BtnPaper.Name = "BtnPaper";
            this.BtnPaper.Size = new System.Drawing.Size(120, 230);
            this.BtnPaper.TabIndex = 1;
            this.BtnPaper.UseVisualStyleBackColor = true;
            this.BtnPaper.Click += new System.EventHandler(this.BtnPaper_Click);
            // 
            // BtnRock
            // 
            this.BtnRock.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnRock.BackgroundImage")));
            this.BtnRock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnRock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnRock.Location = new System.Drawing.Point(424, 458);
            this.BtnRock.Name = "BtnRock";
            this.BtnRock.Size = new System.Drawing.Size(120, 230);
            this.BtnRock.TabIndex = 2;
            this.BtnRock.UseVisualStyleBackColor = true;
            this.BtnRock.Click += new System.EventHandler(this.BtnRock_Click);
            // 
            // LblScissor
            // 
            this.LblScissor.AutoSize = true;
            this.LblScissor.BackColor = System.Drawing.Color.Transparent;
            this.LblScissor.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblScissor.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.LblScissor.Location = new System.Drawing.Point(55, 432);
            this.LblScissor.Name = "LblScissor";
            this.LblScissor.Size = new System.Drawing.Size(75, 23);
            this.LblScissor.TabIndex = 4;
            this.LblScissor.Text = "CHECK";
            // 
            // LblPaper
            // 
            this.LblPaper.AutoSize = true;
            this.LblPaper.BackColor = System.Drawing.Color.Transparent;
            this.LblPaper.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblPaper.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.LblPaper.Location = new System.Drawing.Point(260, 432);
            this.LblPaper.Name = "LblPaper";
            this.LblPaper.Size = new System.Drawing.Size(75, 23);
            this.LblPaper.TabIndex = 5;
            this.LblPaper.Text = "CHECK";
            this.LblPaper.Click += new System.EventHandler(this.label2_Click);
            // 
            // LblRock
            // 
            this.LblRock.AutoSize = true;
            this.LblRock.BackColor = System.Drawing.Color.Transparent;
            this.LblRock.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblRock.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.LblRock.Location = new System.Drawing.Point(446, 432);
            this.LblRock.Name = "LblRock";
            this.LblRock.Size = new System.Drawing.Size(75, 23);
            this.LblRock.TabIndex = 6;
            this.LblRock.Text = "CHECK";
            // 
            // PnlUserCard
            // 
            this.PnlUserCard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PnlUserCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlUserCard.Controls.Add(this.LblUserCard);
            this.PnlUserCard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.PnlUserCard.Location = new System.Drawing.Point(12, 72);
            this.PnlUserCard.Name = "PnlUserCard";
            this.PnlUserCard.Size = new System.Drawing.Size(200, 300);
            this.PnlUserCard.TabIndex = 7;
            // 
            // LblUserCard
            // 
            this.LblUserCard.AutoSize = true;
            this.LblUserCard.Location = new System.Drawing.Point(67, 140);
            this.LblUserCard.Name = "LblUserCard";
            this.LblUserCard.Size = new System.Drawing.Size(63, 13);
            this.LblUserCard.TabIndex = 0;
            this.LblUserCard.Text = "DefaultCard";
            // 
            // PnlComputerCard
            // 
            this.PnlComputerCard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PnlComputerCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlComputerCard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.PnlComputerCard.Location = new System.Drawing.Point(362, 72);
            this.PnlComputerCard.Name = "PnlComputerCard";
            this.PnlComputerCard.Size = new System.Drawing.Size(200, 300);
            this.PnlComputerCard.TabIndex = 8;
            // 
            // BtnLockIn
            // 
            this.BtnLockIn.BackColor = System.Drawing.Color.White;
            this.BtnLockIn.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.BtnLockIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.BtnLockIn.Location = new System.Drawing.Point(181, 388);
            this.BtnLockIn.Name = "BtnLockIn";
            this.BtnLockIn.Size = new System.Drawing.Size(220, 35);
            this.BtnLockIn.TabIndex = 3;
            this.BtnLockIn.Text = "Lock in ";
            this.BtnLockIn.UseVisualStyleBackColor = false;
            this.BtnLockIn.Click += new System.EventHandler(this.button4_Click);
            // 
            // PNLoutcome
            // 
            this.PNLoutcome.BackColor = System.Drawing.Color.Transparent;
            this.PNLoutcome.Location = new System.Drawing.Point(218, 130);
            this.PNLoutcome.Name = "PNLoutcome";
            this.PNLoutcome.Size = new System.Drawing.Size(138, 190);
            this.PNLoutcome.TabIndex = 11;
            // 
            // UserScore
            // 
            this.UserScore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.UserScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.UserScore.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserScore.ForeColor = System.Drawing.SystemColors.Window;
            this.UserScore.Location = new System.Drawing.Point(234, 38);
            this.UserScore.Name = "UserScore";
            this.UserScore.ReadOnly = true;
            this.UserScore.Size = new System.Drawing.Size(42, 66);
            this.UserScore.TabIndex = 12;
            this.UserScore.Text = "0";
            this.UserScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ComputerScore
            // 
            this.ComputerScore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.ComputerScore.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ComputerScore.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComputerScore.ForeColor = System.Drawing.SystemColors.Window;
            this.ComputerScore.Location = new System.Drawing.Point(296, 38);
            this.ComputerScore.Name = "ComputerScore";
            this.ComputerScore.ReadOnly = true;
            this.ComputerScore.Size = new System.Drawing.Size(42, 66);
            this.ComputerScore.TabIndex = 13;
            this.ComputerScore.Text = "0";
            this.ComputerScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 33);
            this.label1.TabIndex = 14;
            this.label1.Text = "default";
            // 
            // GameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(574, 712);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ComputerScore);
            this.Controls.Add(this.UserScore);
            this.Controls.Add(this.PNLoutcome);
            this.Controls.Add(this.PnlComputerCard);
            this.Controls.Add(this.PnlUserCard);
            this.Controls.Add(this.LblRock);
            this.Controls.Add(this.LblPaper);
            this.Controls.Add(this.LblScissor);
            this.Controls.Add(this.BtnLockIn);
            this.Controls.Add(this.BtnRock);
            this.Controls.Add(this.BtnPaper);
            this.Controls.Add(this.BtnScissor);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Location = new System.Drawing.Point(100, 100);
            this.MaximizeBox = false;
            this.Name = "GameForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GameForm";
            this.Load += new System.EventHandler(this.GameForm_Load);
            this.PnlUserCard.ResumeLayout(false);
            this.PnlUserCard.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnScissor;
        private System.Windows.Forms.Button BtnPaper;
        private System.Windows.Forms.Button BtnRock;
        private System.Windows.Forms.Label LblScissor;
        private System.Windows.Forms.Label LblPaper;
        private System.Windows.Forms.Label LblRock;
        private System.Windows.Forms.Panel PnlUserCard;
        private System.Windows.Forms.Panel PnlComputerCard;
        private System.Windows.Forms.Label LblUserCard;
        private System.Windows.Forms.Button BtnLockIn;
        private System.Windows.Forms.Panel PNLoutcome;
        private System.Windows.Forms.TextBox UserScore;
        private System.Windows.Forms.TextBox ComputerScore;
        private System.Windows.Forms.Label label1;
    }
}