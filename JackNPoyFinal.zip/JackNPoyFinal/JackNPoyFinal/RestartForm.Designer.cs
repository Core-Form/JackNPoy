﻿namespace JackNPoyFinal
{
    partial class RestartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RestartForm));
            this.BtnRestart = new System.Windows.Forms.Button();
            this.BtnQuit = new System.Windows.Forms.Button();
            this.LblResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnRestart
            // 
            this.BtnRestart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.BtnRestart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnRestart.BackgroundImage")));
            this.BtnRestart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnRestart.Location = new System.Drawing.Point(158, 102);
            this.BtnRestart.Name = "BtnRestart";
            this.BtnRestart.Size = new System.Drawing.Size(140, 40);
            this.BtnRestart.TabIndex = 0;
            this.BtnRestart.UseVisualStyleBackColor = false;
            this.BtnRestart.Click += new System.EventHandler(this.BtnRestart_Click);
            // 
            // BtnQuit
            // 
            this.BtnQuit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.BtnQuit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnQuit.BackgroundImage")));
            this.BtnQuit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BtnQuit.Location = new System.Drawing.Point(158, 159);
            this.BtnQuit.Name = "BtnQuit";
            this.BtnQuit.Size = new System.Drawing.Size(140, 40);
            this.BtnQuit.TabIndex = 1;
            this.BtnQuit.UseVisualStyleBackColor = false;
            this.BtnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // LblResult
            // 
            this.LblResult.AutoSize = true;
            this.LblResult.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblResult.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.LblResult.Location = new System.Drawing.Point(165, 39);
            this.LblResult.Name = "LblResult";
            this.LblResult.Size = new System.Drawing.Size(126, 38);
            this.LblResult.TabIndex = 2;
            this.LblResult.Text = "Default";
            this.LblResult.TextChanged += new System.EventHandler(this.LblResult_TextChanged);
            // 
            // RestartForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(460, 260);
            this.Controls.Add(this.LblResult);
            this.Controls.Add(this.BtnQuit);
            this.Controls.Add(this.BtnRestart);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RestartForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RestartForm";
            this.Load += new System.EventHandler(this.RestartForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnRestart;
        private System.Windows.Forms.Button BtnQuit;
        private System.Windows.Forms.Label LblResult;
    }
}