﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;


namespace JackNPoyFinal
{
    public partial class StartForm : Form
    {
        public SoundPlayer BGsound;
       
        public StartForm()
        {
            InitializeComponent();
            this.MouseClick += new MouseEventHandler(this.ClickStart);
            BGsound = new SoundPlayer("Jazz.wav");

        }

        GameForm GForm = new GameForm();
        
        private void Form1_Load(object sender, EventArgs e)
        {
            BGsound.Play();
            TMBlinker.Start();
            TMBlinker.Enabled = true;

            
            
            
        }

        private void ClickStart(object sender, MouseEventArgs e)
        {

            switch (e.Button)
            {
                case MouseButtons.Left:
                    GForm.Show();
                    
                    this.Hide();
                    break;
                case MouseButtons.Right:
                    GForm.Show();
                    
                    this.Hide();
                    break;

            }
            
        }

        private void BtnUnmute_Click(object sender, EventArgs e)
        {

        }

        private void BtnMute_Click(object sender, EventArgs e)
        {
            BGsound.Stop();
            BtnMute.Visible = false;
            BtnUnmute.Visible = true;
        }

        private void BtnUnmute_Click_1(object sender, EventArgs e)
        {
            BGsound.Play();
            BtnUnmute.Visible = false;
            BtnMute.Visible = true;

        }

        private void TMBlinker_Tick(object sender, EventArgs e)
        {
            Random colorvalue = new Random();
            int A = colorvalue.Next(0, 255);
            int B = colorvalue.Next(0, 255);
            int C = colorvalue.Next(0, 255);

            LblStart.ForeColor = System.Drawing.Color.FromArgb(A, B, C);
        }

        private void TBPlayername_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void TBplayername_TextChanged_1(object sender, EventArgs e)
        {
           
        }

    }

}
